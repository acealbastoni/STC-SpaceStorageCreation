package com.mohamedabdelhamid.demo.enums;

public enum AccessLevel {
	VIEW,
	EDIT
}
