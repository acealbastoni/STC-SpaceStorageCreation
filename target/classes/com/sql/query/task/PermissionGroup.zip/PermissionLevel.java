package com.mohamedabdelhamid.demo.domains;

public enum PermissionLevel {
    VIEW,
    EDIT
}
