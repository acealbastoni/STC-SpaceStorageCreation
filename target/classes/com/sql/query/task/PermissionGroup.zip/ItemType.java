package com.mohamedabdelhamid.demo.domains;

public enum ItemType {
    SPACE,
    FOLDER,
    FILE
}
